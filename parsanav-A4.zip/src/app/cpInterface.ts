export interface Cat{
    breed: string;
    location: string;
    bodytype: string;
    Pattern: string;
}

export interface Dog{
    breed: string;
    location: string;
    coat: string;
    color: string;
}